import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyA1zb6Pprn_8XOP6v7z1XftFhH3tj4Of9w",
  authDomain: "my-movie-app-793be.firebaseapp.com",
  projectId: "my-movie-app-793be",
  storageBucket: "my-movie-app-793be.appspot.com",
  messagingSenderId: "866493311332",
  appId: "1:866493311332:web:e36a9c653b88dca8c77271",
  measurementId: "G-0J5ZX008F6"
};


const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth }