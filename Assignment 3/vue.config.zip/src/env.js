export default {
    apikey: "3f5b643d"
}